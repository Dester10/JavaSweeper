package sweeper;

public enum GameState {
    PLAYED,
    BOMBED,
    WINNER
}
